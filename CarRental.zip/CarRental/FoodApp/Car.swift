//
//  Car.swift
//  FoodApp
//
//  Created by MacStudent on 2020-03-06.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import Foundation
class Car{
    var name: String
    var rate: Double
    var status: Bool
    var milage: Int
    init(name: String, rate: Double, status: Bool, milage: Int){
        self.name = name
        self.rate = rate
        self.status = status
        self.milage = milage
    }
}
