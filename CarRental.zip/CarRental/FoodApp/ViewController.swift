//
//  ViewController.swift
//  FoodApp
//
//  Created by MacStudent on 2020-03-05.
//  Copyright © 2020 MacStudent. All rights reserved.
/*
create an app for car rental
menu showing car names
show its rate and picture
let the user choose how many days
let user pick one otion
<18 8-64 65+
if <18: add 5$ per day,if 65+ increase the total by 10%
let the user pick one or more of these options
Navigator child_seat  unlimited_milege
add 7$ per day for navigator
6$ fo child seat
1.5 times rate for unlimited
Finally add 13% for total and display
*/

import UIKit

class ViewController: UIViewController, UIPickerViewDelegate,UIPickerViewDataSource  {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return avCars.count
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        carName = avCars[row].name
        return avCars[row].name
    }
    var carName: String? = nil
    @IBOutlet weak var mealImage: UIImageView!
    @IBOutlet weak var less: UIButton!
    @IBOutlet weak var high: UIButton!
    @IBOutlet weak var nav: UIButton!
    @IBOutlet weak var child: UIButton!
    @IBOutlet weak var mil: UIButton!
    @IBOutlet weak var meals: UIPickerView!
    @IBOutlet weak var amount: UILabel!
    @IBOutlet weak var qty: UITextField!
    @IBOutlet weak var price: UILabel!
    //create an array from the class car
    var rentals: [Car] = []
    var avCars: [Car]=[]
    
        func findCars(){
            for x in rentals{
            if x.status{
                avCars.append(x)
            }
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        rentals.append(Car(name:"Nissan", rate:35.5, status:false, milage:3584))
        rentals.append(Car(name:"Ford", rate:40.5, status:true, milage:2741))
        rentals.append(Car(name:"BMW", rate:95.5, status:true, milage:6850))
        rentals.append(Car(name:"Honda", rate:30.5, status:true, milage:1452))
        rentals.append(Car(name:"Toyota", rate:38.5, status:false, milage:2201))
        rentals.append(Car(name:"Dodge", rate:45.5, status:true, milage:7410))
        //connect data
        findCars()
        self.meals.delegate = self
        self.meals.dataSource = self
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
        price.text = String(avCars[row].rate)
        mealImage.image = UIImage(named: avCars[row].name)
        //make sure the name of the image file exactly the name in the array of food
        
    }

    func changeStatus(){
        for x in rentals{
            if x.name == carName{
                x.status = false
            }
        }
    }
    var fp = 0.0
    
    @IBAction func but1(_ sender: UIButton) {
        if sender.isSelected
        {
            sender.isSelected = false
            fp = fp-(Double(qty.text!)!*5)
        }
        else
        {
            
            high.isSelected = false
            sender.isSelected = true
            fp = fp+(Double(qty.text!)!*5)
            
        }
        
    }
    
    @IBAction func but2(_ sender: UIButton) {
        if sender.isSelected
            {
                sender.isSelected = false
                fp = fp/1.1
            }
            else
            {
                less.isSelected = false
                sender.isSelected = true
                fp = fp*1.1
            }
    }
    

    
    
    @IBAction func order(_ sender: Any) {
        if let days = qty.text, !days.isEmpty{
            let rate = Double(price.text!)!
            let da = Double(days)
            let total = fp * Double(da!) * Double(rate) * 1.13
            amount.text = String(format: "%.2f", total)
            changeStatus()
            findCars()
        }
    }
}

