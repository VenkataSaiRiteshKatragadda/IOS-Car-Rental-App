//
//  Food.swift
//  FoodApp
//
//  Created by MacStudent on 2020-03-06.
//  Copyright © 2020 MacStudent. All rights reserved.
//

import Foundation
class Food {
    var name: String
    var price: Double
    var available: Bool

init(name: String, price: Double, available: Bool){
    self.name = name
    self.price = price
    self.available = available
}
}
